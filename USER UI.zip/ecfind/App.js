import React, { useState, useRef } from 'react';
import { 
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet, 
  SafeAreaView, 
  ImageBackground, 
  PanResponder, 
  Animated,
  Dimensions,
  Image,
  ScrollView,
  Platform,
  StatusBar,
  Modal,
  TextInput
} from 'react-native';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');
const BOTTOM_SHEET_MAX_HEIGHT = SCREEN_HEIGHT * 0.8;
const BOTTOM_SHEET_MIN_HEIGHT = 180;

// Calculate status bar height for different platforms
const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 44 : StatusBar.currentHeight;

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('Home');
  const [isExpanded, setIsExpanded] = useState(false);
  const [showStatusOptions, setShowStatusOptions] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState('Open');
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [siteToDelete, setSiteToDelete] = useState(null);
  
  // New state variables for editable fields - initialize as empty
  const [address, setAddress] = useState('');
  const [maxCapacity, setMaxCapacity] = useState('');
  const [slotsAvailable, setSlotsAvailable] = useState('0');
  
  const bottomSheetHeight = useRef(new Animated.Value(BOTTOM_SHEET_MIN_HEIGHT)).current;

  // PanResponder for bottom sheet drag
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderMove: (event, gestureState) => {
        // Only allow dragging up from min height
        if (gestureState.dy < 0) {
          const newHeight = Math.max(BOTTOM_SHEET_MIN_HEIGHT, BOTTOM_SHEET_MIN_HEIGHT - gestureState.dy);
          bottomSheetHeight.setValue(newHeight);
        }
      },
      onPanResponderRelease: (event, gestureState) => {
        if (gestureState.dy < -50) {
          // Swiped up significantly - expand
          expandBottomSheet();
        } else {
          // Return to min height
          collapseBottomSheet();
        }
      },
    })
  ).current;

  const expandBottomSheet = () => {
    setIsExpanded(true);
    Animated.spring(bottomSheetHeight, {
      toValue: BOTTOM_SHEET_MAX_HEIGHT,
      useNativeDriver: false,
      tension: 50,
      friction: 7,
    }).start();
  };

  const collapseBottomSheet = () => {
    setIsExpanded(false);
    Animated.spring(bottomSheetHeight, {
      toValue: BOTTOM_SHEET_MIN_HEIGHT,
      useNativeDriver: false,
      tension: 50,
      friction: 7,
    }).start();
  };

  // Delete confirmation functions
  const handleDeletePress = (siteName) => {
    setSiteToDelete(siteName);
    setShowDeleteConfirmation(true);
  };

  const confirmDelete = () => {
    console.log(`Deleting site: ${siteToDelete}`);
    // Add your actual delete logic here
    setShowDeleteConfirmation(false);
    setSiteToDelete(null);
  };

  const cancelDelete = () => {
    setShowDeleteConfirmation(false);
    setSiteToDelete(null);
  };

  // Slots Available functions
  const incrementSlots = () => {
    const current = parseInt(slotsAvailable) || 0;
    setSlotsAvailable((current + 1).toString());
  };

  const decrementSlots = () => {
    const current = parseInt(slotsAvailable) || 0;
    if (current > 0) {
      setSlotsAvailable((current - 1).toString());
    }
  };

  // Delete Confirmation Modal Component
  const DeleteConfirmationModal = () => (
    <Modal
      visible={showDeleteConfirmation}
      transparent={true}
      animationType="fade"
      onRequestClose={cancelDelete}
    >
      <View style={styles.deleteModalOverlay}>
        <View style={styles.deleteModalContent}>
          <Text style={styles.deleteModalTitle}>Delete Confirmation</Text>
          <Text style={styles.deleteModalMessage}>
            Are you sure you want to delete "{siteToDelete}"?
          </Text>
          
          <View style={styles.deleteModalButtons}>
            <TouchableOpacity 
              style={[styles.deleteModalButton, styles.cancelDeleteButton]}
              onPress={cancelDelete}
            >
              <Text style={styles.cancelDeleteButtonText}>Cancel</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[styles.deleteModalButton, styles.confirmDeleteButton]}
              onPress={confirmDelete}
            >
              <Text style={styles.confirmDeleteButtonText}>Confirm</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  // Home Screen Component - Updated with evacuation site info
  const HomeScreen = () => (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      
      {/* Header with user icon */}
      <View style={styles.homeHeader}>
        <TouchableOpacity 
          style={styles.userIconButton}
          onPress={() => setCurrentScreen('UserProfile')}
        >
          <Text style={styles.userIcon}>👤</Text>
        </TouchableOpacity>
        <View style={styles.homeHeaderPlaceholder} />
      </View>

      {/* Map Background */}
      <ImageBackground 
        source={{ 
          uri: 'https://images.unsplash.com/photo-1540959733332-abcbf6cb1453?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80' 
        }} 
        style={styles.homeMapImage}
        resizeMode="cover"
      >
        <View style={styles.homeMapOverlay}>
          <Text style={styles.homeMapLabel}>MAP HERE</Text>
        </View>
      </ImageBackground>

      {/* Evacuation Site Info Bottom Sheet */}
      <Animated.View 
        style={[
          styles.homeBottomSheet,
          { height: bottomSheetHeight }
        ]}
        {...panResponder.panHandlers}
      >
        {/* Drag Handle */}
        <View style={styles.dragHandle}>
          <View style={styles.dragHandleBar} />
        </View>

        {/* Bottom Sheet Content */}
        <View style={styles.bottomSheetContent}>
          {/* Default View (When not dragged up) */}
          <View style={[
            styles.defaultView,
            { display: isExpanded ? 'none' : 'flex' }
          ]}>
            <Text style={styles.locationName}>Renzos Evacuation Place</Text>
            
            <View style={styles.buttonsRow}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.directionsBtn]}
                onPress={() => console.log('Directions pressed')}
              >
                <Text style={styles.actionButtonText}>DIRECTIONS</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.actionButton, styles.infoBtn]}
                onPress={() => setCurrentScreen('LocationDetail')}
              >
                <Text style={styles.actionButtonText}>INFO</Text>
              </TouchableOpacity>
            </View>

            {/* Location Details Section */}
            <View style={styles.locationDetailsSection}>
              <Text style={styles.locationDetailsTitle}> </Text>
            </View>
          </View>

          {/* Expanded View - Only visible when sheet is dragged up */}
          <View style={[
            styles.expandedView,
            { display: isExpanded ? 'flex' : 'none' }
          ]}>
            <ScrollView 
              style={styles.expandedScrollView}
              showsVerticalScrollIndicator={false}
            >
              <Text style={styles.expandedTitle}>Full Location Details</Text>
              
              {/* Evacuation Images Section */}
              <View style={styles.imagesSection}>
                <Text style={styles.sectionTitle}>Evacuation Site Images</Text>
                <View style={styles.imagesContainer}>
                  {/* Image 1 */}
                  <View style={styles.imageWrapper}>
                    <Image 
                      source={{ uri: 'https://images.unsplash.com/photo-1582735689363-91f03063660c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80' }}
                      style={styles.evacuationImage}
                      resizeMode="cover"
                    />
                    <Text style={styles.imageLabel}>Main Entrance</Text>
                  </View>
                  
                  {/* Image 2 */}
                  <View style={styles.imageWrapper}>
                    <Image 
                      source={{ uri: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80' }}
                      style={styles.evacuationImage}
                      resizeMode="cover"
                    />
                    <Text style={styles.imageLabel}>Facility Overview</Text>
                  </View>
                  
                  {/* Placeholder for more images */}
                  <View style={styles.imageWrapper}>
                    <View style={styles.placeholderImage}>
                      <Text style={styles.placeholderText}>+ Add Photo</Text>
                    </View>
                    <Text style={styles.imageLabel}>Add More</Text>
                  </View>
                </View>
              </View>

              {/* Location Information */}
              <View style={styles.detailSection}>
                <Text style={styles.sectionTitle}>Location Information</Text>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Address:</Text>
                  <Text style={styles.detailText}>123 Cuban Quezon City</Text>
                </View>
                
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Contact:</Text>
                  <Text style={styles.detailText}>09383824384</Text>
                </View>
                
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Capacity:</Text>
                  <Text style={styles.detailText}>200 People</Text>
                </View>
                
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Availability:</Text>
                  <Text style={styles.availabilityText}>25 Slots Available</Text>
                </View>

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Facilities:</Text>
                  <Text style={styles.detailText}>Toilets, Showers, Beds</Text>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </Animated.View>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal />
    </SafeAreaView>
  );

  // Map Screen Component with Draggable Bottom Sheet
  const MapScreen = () => (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1a1a1a" />
      
      {/* Header with status bar padding */}
      <View style={styles.headerContainer}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentScreen('Home')}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Map View</Text>
          <View style={styles.placeholder} />
        </View>
      </View>

      {/* Map Background */}
      <ImageBackground 
        source={{ 
          uri: 'https://images.unsplash.com/photo-1540959733332-abcbf6cb1453?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80' 
        }} 
        style={styles.mapImage}
        resizeMode="cover"
      >
        <View style={styles.mapOverlay}>
          <Text style={styles.mapLabel}>Build Map Image</Text>
        </View>
      </ImageBackground>

      {/* Draggable Bottom Sheet */}
      <Animated.View 
        style={[
          styles.bottomSheet,
          { height: bottomSheetHeight }
        ]}
        {...panResponder.panHandlers}
      >
        {/* Drag Handle */}
        <View style={styles.dragHandle}>
          <View style={styles.dragHandleBar} />
        </View>

        {/* Bottom Sheet Content */}
        <View style={styles.bottomSheetContent}>
          {/* Default View (When not dragged up) */}
          <View style={[
            styles.defaultView,
            { display: isExpanded ? 'none' : 'flex' }
          ]}>
            <Text style={styles.locationName}>Renzos Evacuation Place</Text>
            
            <View style={styles.buttonsRow}>
              <TouchableOpacity 
                style={[styles.actionButton, styles.directionsBtn]}
                onPress={() => console.log('Directions pressed')}
              >
                <Text style={styles.actionButtonText}>DIRECTIONS</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[styles.actionButton, styles.infoBtn]}
                onPress={() => setCurrentScreen('LocationDetail')}
              >
                <Text style={styles.actionButtonText}>INFO</Text>
              </TouchableOpacity>
            </View>

            {/* Location Details Section */}
            <View style={styles.locationDetailsSection}>
              <Text style={styles.locationDetailsTitle}>  </Text>
            </View>
          </View>

          {/* Expanded View - Only visible when sheet is dragged up */}
          <View style={[
            styles.expandedView,
            { display: isExpanded ? 'flex' : 'none' }
          ]}>
            <ScrollView 
              style={styles.expandedScrollView}
              showsVerticalScrollIndicator={false}
            >
              <Text style={styles.expandedTitle}>Full Location Details</Text>
              
              {/* Evacuation Images Section */}
              <View style={styles.imagesSection}>
                <Text style={styles.sectionTitle}>Evacuation Site Images</Text>
                <View style={styles.imagesContainer}>
                  {/* Image 1 */}
                  <View style={styles.imageWrapper}>
                    <Image 
                      source={{ uri: 'https://images.unsplash.com/photo-1582735689363-91f03063660c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80' }}
                      style={styles.evacuationImage}
                      resizeMode="cover"
                    />
                    <Text style={styles.imageLabel}>Main Entrance</Text>
                  </View>
                  
                  {/* Image 2 */}
                  <View style={styles.imageWrapper}>
                    <Image 
                      source={{ uri: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80' }}
                      style={styles.evacuationImage}
                      resizeMode="cover"
                    />
                    <Text style={styles.imageLabel}>Facility Overview</Text>
                  </View>
                  
                  {/* Placeholder for more images */}
                  <View style={styles.imageWrapper}>
                    <View style={styles.placeholderImage}>
                      <Text style={styles.placeholderText}>+ Add Photo</Text>
                    </View>
                    <Text style={styles.imageLabel}>Add More</Text>
                  </View>
                </View>
              </View>

              {/* Location Information */}
              <View style={styles.detailSection}>
                <Text style={styles.sectionTitle}>Location Information</Text>
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Address:</Text>
                  <Text style={styles.detailText}>123 Cuban Quezon City</Text>
                </View>
                
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Contact:</Text>
                  <Text style={styles.detailText}>09383824384</Text>
                </View>
                
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Capacity:</Text>
                  <Text style={styles.detailText}>200 People</Text>
                </View>
                
                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Availability:</Text>
                  <Text style={styles.availabilityText}>25 Slots Available</Text>
                </View>

                <View style={styles.detailRow}>
                  <Text style={styles.detailLabel}>Facilities:</Text>
                  <Text style={styles.detailText}>Toilets, Showers, Beds</Text>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </Animated.View>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal />
    </View>
  );

  // Location Detail Screen Component
  const LocationDetailScreen = () => (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      
      {/* Header with status bar padding */}
      <View style={styles.headerContainer}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentScreen('Map')}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}> </Text>
          <View style={styles.placeholder} />
        </View>
      </View>

      {/* Full Details Content */}
      <View style={styles.fullDetailContent}>
        <Text style={styles.fullDetailTitle}>Renzos Evacuation Place</Text>
        
        <View style={styles.fullDetailSection}>
          <View style={styles.fullDetailRow}>
            <Text style={styles.fullDetailLabel}>Address:</Text>
            <Text style={styles.fullDetailText}>123 Cuban Quezon City</Text>
          </View>
          
          <View style={styles.fullDetailRow}>
            <Text style={styles.fullDetailLabel}>Contact:</Text>
            <Text style={styles.fullDetailText}>09383824384</Text>
          </View>
          
          <View style={styles.fullDetailRow}>
            <Text style={styles.fullDetailLabel}>Capacity:</Text>
            <Text style={styles.fullDetailText}>200 People</Text>
          </View>
          
          <View style={styles.fullDetailRow}>
            <Text style={styles.fullDetailLabel}>Availability:</Text>
            <Text style={styles.fullAvailabilityText}>25 Slots Available</Text>
          </View>

          <View style={styles.fullDetailRow}>
            <Text style={styles.fullDetailLabel}>Facilities:</Text>
            <Text style={styles.fullDetailText}>Toilets, Showers, Beds, First Aid</Text>
          </View>
        </View>

        <TouchableOpacity 
          style={[styles.fullDetailButton, styles.directionsButton]}
          onPress={() => console.log('Get Directions pressed')}
        >
          <Text style={styles.fullDetailButtonText}>GET DIRECTIONS</Text>
        </TouchableOpacity>
      </View>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal />
    </View>
  );

  // User Profile Screen Component
  const UserProfileScreen = () => (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      
      {/* Header with status bar padding */}
      <View style={styles.headerContainer}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentScreen('Home')}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>User Profile</Text>
          <View style={styles.placeholder} />
        </View>
      </View>

      {/* Edit Icon at top right */}
      <View style={styles.editIconContainer}>
        <TouchableOpacity 
          style={styles.editIconButton}
          onPress={() => console.log('Edit Profile pressed')}
        >
          <Text style={styles.editIcon}>✏️</Text>
        </TouchableOpacity>
      </View>

      {/* User Profile Content */}
      <View style={styles.profileContent}>
        <View style={styles.profileHeader}>
          <View style={styles.profileIconContainer}>
            <Text style={styles.profileIcon}>👤</Text>
          </View>
          <Text style={styles.profileName}>John Doe</Text>
          <Text style={styles.profileEmail}>john.doe@example.com</Text>
        </View>

        <View style={styles.profileDetails}>
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Phone:</Text>
            <Text style={styles.detailText}>+1 (555) 123-4567</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Role:</Text>
            <Text style={styles.detailText}>Administrator</Text>
          </View>
          
          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Joined:</Text>
            <Text style={styles.detailText}>January 15, 2024</Text>
          </View>
        </View>

        {/* Action Buttons - Updated Evacuation Sites button */}
        <TouchableOpacity 
          style={[styles.profileButton, styles.evacuationSitesButton]}
          onPress={() => setCurrentScreen('EvacuationSites')}
        >
          <Text style={styles.profileButtonText}>EVACUATION SITES</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.profileButton, styles.logoutButton]}
          onPress={() => setCurrentScreen('Home')}
        >
          <Text style={styles.profileButtonText}>LOGOUT</Text>
        </TouchableOpacity>
      </View>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal />
    </View>
  );

  // Evacuation Sites Screen Component - Updated with plus button and removed add site section
  const EvacuationSitesScreen = () => (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      
      {/* Header with status bar padding */}
      <View style={styles.headerContainer}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentScreen('UserProfile')}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Evacuation Sites</Text>
          <View style={styles.placeholder} />
        </View>
      </View>

      {/* Scrollable Content */}
      <ScrollView 
        style={styles.evacuationSitesScrollView}
        showsVerticalScrollIndicator={true}
        contentContainerStyle={styles.evacuationSitesContent}
      >
        {/* Main Title */}
        <Text style={styles.evacuationSitesMainTitle}>Execution Sites</Text>

        {/* Site Manager Header with Plus Button */}
        <View style={styles.siteManagerHeaderWithButton}>
          <View style={styles.siteManagerHeader}>
            <Text style={styles.siteManagerTitle}>SITE MANAGER</Text>
          </View>
          <TouchableOpacity 
            style={styles.plusButton}
            onPress={() => setCurrentScreen('AddEvacuationSite')}
          >
            <Text style={styles.plusButtonText}>+</Text>
          </TouchableOpacity>
        </View>

        {/* List of Evacuation Sites */}
        <View style={styles.sitesListContainer}>
          <Text style={styles.sectionTitleBold}>LIST OF EVAC SITES</Text>
          <View style={styles.sitesList}>
            <Text style={styles.siteItem}>site 1</Text>
            <Text style={styles.siteItem}>site 2</Text>
            <Text style={styles.siteItem}>site 3</Text>
            <Text style={styles.siteItem}>site 4</Text>
            <Text style={styles.siteItem}>site 5</Text>
            <Text style={styles.siteItem}>site 6</Text>
            <Text style={styles.siteItem}>site 7</Text>
          </View>
        </View>

        {/* Divider */}
        <View style={styles.divider} />

        {/* Evacuation Sites Management Section */}
        <View style={styles.evacManagementSection}>
          <Text style={styles.sectionTitleBold}>EVACUATION SITES</Text>
          <View style={styles.siteManagementList}>
            {/* Site 1 */}
            <View style={styles.siteManagementItem}>
              <View style={styles.siteInfo}>
                <Text style={styles.siteName}>Site 1</Text>
                <Text style={styles.requestNotes}>Requests notes</Text>
              </View>
              <TouchableOpacity 
                style={styles.deleteButton}
                onPress={() => handleDeletePress('Site 1')}
              >
                <Text style={styles.deleteButtonText}>Delete</Text>
              </TouchableOpacity>
            </View>
            
            {/* Site 2 */}
            <View style={styles.siteManagementItem}>
              <View style={styles.siteInfo}>
                <Text style={styles.siteName}>Site 2</Text>
                <Text style={styles.requestNotes}>Requests notes</Text>
              </View>
              <TouchableOpacity 
                style={styles.deleteButton}
                onPress={() => handleDeletePress('Site 2')}
              >
                <Text style={styles.deleteButtonText}>Delete</Text>
              </TouchableOpacity>
            </View>
            
            {/* Site 3 */}
            <View style={styles.siteManagementItem}>
              <View style={styles.siteInfo}>
                <Text style={styles.siteName}>Site 3</Text>
                <Text style={styles.requestNotes}>Requests notes</Text>
              </View>
              <TouchableOpacity 
                style={styles.deleteButton}
                onPress={() => handleDeletePress('Site 3')}
              >
                <Text style={styles.deleteButtonText}>Delete</Text>
              </TouchableOpacity>
            </View>
            
            {/* Site 4 */}
            <View style={styles.siteManagementItem}>
              <View style={styles.siteInfo}>
                <Text style={styles.siteName}>Site 4</Text>
                <Text style={styles.requestNotes}>Requests notes</Text>
              </View>
              <TouchableOpacity 
                style={styles.deleteButton}
                onPress={() => handleDeletePress('Site 4')}
              >
                <Text style={styles.deleteButtonText}>Delete</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <TouchableOpacity 
            style={[styles.evacuationButton, styles.returnButton]}
            onPress={() => setCurrentScreen('UserProfile')}
          >
            <Text style={styles.evacuationButtonText}>Return to menu</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal />
    </View>
  );

  // Add Evacuation Site Screen Component
  const AddEvacuationSiteScreen = () => (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      
      {/* Header with status bar padding */}
      <View style={styles.headerContainer}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentScreen('EvacuationSites')}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Add Evacuation Site</Text>
          <View style={styles.placeholder} />
        </View>
      </View>

      {/* Map Picture as Background */}
      <ImageBackground 
        source={{ 
          uri: 'https://images.unsplash.com/photo-1540959733332-abcbf6cb1453?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80' 
        }} 
        style={styles.addSiteMapImage}
        resizeMode="cover"
      >
        <View style={styles.addSiteMapOverlay}>
          <Text style={styles.addSiteMapLabel}>MAP PICTURE ONLY</Text>
          <Text style={styles.addSiteInstruction}>Tap on the map to select location</Text>
        </View>
      </ImageBackground>

      {/* OK/Cancel Buttons at Bottom */}
      <View style={styles.bottomActionContainer}>
        <TouchableOpacity 
          style={[styles.actionButton, styles.cancelButton]}
          onPress={() => setCurrentScreen('EvacuationSites')}
        >
          <Text style={styles.actionButtonText}>CANCEL</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.actionButton, styles.okButton]}
          onPress={() => setCurrentScreen('EvacSiteDetails')}
        >
          <Text style={styles.actionButtonText}>OK</Text>
        </TouchableOpacity>
      </View>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal />
    </View>
  );

  // Evac Site Details Screen Component with +/- buttons for Slots Available
  const EvacSiteDetailsScreen = () => (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
      
      {/* Header with status bar padding */}
      <View style={styles.headerContainer}>
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => setCurrentScreen('AddEvacuationSite')}
          >
            <Text style={styles.backButtonText}>←</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Evac Site Details</Text>
          <View style={styles.placeholder} />
        </View>
      </View>

      {/* Content */}
      <ScrollView 
        style={styles.evacSiteDetailsScrollView}
        contentContainerStyle={styles.evacSiteDetailsContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Main Title */}
        <Text style={styles.evacSiteMainTitle}>EVAC SITE</Text>
        
        {/* Added space between title and details section */}
        <View style={styles.titleSpacing} />
        
        {/* Details Section */}
        <View style={styles.detailsSection}>
          <Text style={styles.detailsTitle}>DETAILS</Text>
          
          {/* Address */}
          <View style={styles.detailField}>
            <Text style={styles.detailLabel}>Address</Text>
            <TextInput
              style={styles.detailInput}
              value={address}
              onChangeText={setAddress}
              placeholder="Enter address here"
              placeholderTextColor="#999"
              multiline={true}
              numberOfLines={3}
              textAlignVertical="top"
            />
          </View>
          
          {/* Maximum Capacity */}
          <View style={styles.detailField}>
            <Text style={styles.detailLabel}>Maximum Capacity</Text>
            <TextInput
              style={styles.detailInput}
              value={maxCapacity}
              onChangeText={setMaxCapacity}
              placeholder="Enter capacity"
              placeholderTextColor="#999"
              keyboardType="numeric"
            />
          </View>
          
          {/* Slots Available - Updated with +/- buttons */}
          <View style={styles.detailField}>
            <Text style={styles.detailLabel}>Slots Available</Text>
            <View style={styles.slotsContainer}>
              <TouchableOpacity 
                style={styles.slotButton}
                onPress={decrementSlots}
              >
                <Text style={styles.slotButtonText}>-</Text>
              </TouchableOpacity>
              
              <TextInput
                style={styles.slotsInput}
                value={slotsAvailable}
                onChangeText={setSlotsAvailable}
                placeholder="0"
                placeholderTextColor="#999"
                keyboardType="numeric"
                textAlign="center"
              />
              
              <TouchableOpacity 
                style={styles.slotButton}
                onPress={incrementSlots}
              >
                <Text style={styles.slotButtonText}>+</Text>
              </TouchableOpacity>
            </View>
          </View>
          
          {/* Status */}
          <View style={styles.detailField}>
            <Text style={styles.detailLabel}>Status</Text>
            <TouchableOpacity 
              style={styles.statusDropdown}
              onPress={() => setShowStatusOptions(true)}
            >
              <Text style={styles.statusDropdownText}>{selectedStatus}</Text>
              <Text style={styles.dropdownArrow}>▼</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Return to Menu Button */}
        <TouchableOpacity 
          style={[styles.evacuationButton, styles.returnButton]}
          onPress={() => setCurrentScreen('EvacuationSites')}
        >
          <Text style={styles.evacuationButtonText}>Return to menu</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Status Options Modal */}
      <Modal
        visible={showStatusOptions}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowStatusOptions(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Select Status</Text>
            
            <TouchableOpacity 
              style={[
                styles.statusOption,
                selectedStatus === 'Open' && styles.selectedStatusOption
              ]}
              onPress={() => {
                setSelectedStatus('Open');
                setShowStatusOptions(false);
              }}
            >
              <Text style={styles.statusOptionText}>Open</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={[
                styles.statusOption,
                selectedStatus === 'Abandoned' && styles.selectedStatusOption
              ]}
              onPress={() => {
                setSelectedStatus('Abandoned');
                setShowStatusOptions(false);
              }}
            >
              <Text style={styles.statusOptionText}>Abandoned</Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.modalCloseButton}
              onPress={() => setShowStatusOptions(false)}
            >
              <Text style={styles.modalCloseButtonText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal />
    </View>
  );

  // Render the current screen
  const renderScreen = () => {
    switch (currentScreen) {
      case 'Map':
        return <MapScreen />;
      case 'LocationDetail':
        return <LocationDetailScreen />;
      case 'UserProfile':
        return <UserProfileScreen />;
      case 'EvacuationSites':
        return <EvacuationSitesScreen />;
      case 'AddEvacuationSite':
        return <AddEvacuationSiteScreen />;
      case 'EvacSiteDetails':
        return <EvacSiteDetailsScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return renderScreen();
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  // Home Screen Header Styles
  homeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    paddingTop: STATUSBAR_HEIGHT + 12,
    backgroundColor: '#f8f9fa',
  },
  userIconButton: {
    padding: 8,
    backgroundColor: 'rgba(0,122,255,0.1)',
    borderRadius: 20,
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  userIcon: {
    fontSize: 24,
  },
  homeHeaderPlaceholder: {
    width: 44,
  },
  // Home Screen Map Background
  homeMapImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  homeMapOverlay: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 10,
  },
  homeMapLabel: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
  },
  // Home Screen Bottom Sheet
  homeBottomSheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 10,
    overflow: 'hidden',
  },
  // Header container with status bar padding
  headerContainer: {
    backgroundColor: '#1a1a1a',
    paddingTop: STATUSBAR_HEIGHT,
  },
  // Header Styles
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#1a1a1a',
    height: 50,
  },
  backButton: {
    padding: 12,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 8,
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  backButtonText: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    lineHeight: 28,
    marginTop: -2,
  },
  headerTitle: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  placeholder: {
    width: 44,
  },
  // Edit Icon Styles
  editIconContainer: {
    alignItems: 'flex-end',
    paddingHorizontal: 20,
    paddingTop: 10,
    paddingBottom: 5,
  },
  editIconButton: {
    padding: 8,
    backgroundColor: 'rgba(0,122,255,0.1)',
    borderRadius: 20,
    width: 44,
    height: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  editIcon: {
    fontSize: 20,
  },
  // Home Screen Styles
  topContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    letterSpacing: 1,
  },
  subtitle: {
    fontSize: 24,
    color: '#666',
    fontWeight: '600',
  },
  // Map Screen Styles
  mapImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapOverlay: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  mapLabel: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
  },
  // Bottom Sheet Styles
  bottomSheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 10,
    overflow: 'hidden',
  },
  dragHandle: {
    alignItems: 'center',
    paddingVertical: 8,
  },
  dragHandleBar: {
    width: 40,
    height: 4,
    backgroundColor: '#ccc',
    borderRadius: 2,
  },
  bottomSheetContent: {
    flex: 1,
    padding: 20,
  },
  // Default View (When not dragged up)
  defaultView: {
    flex: 1,
    justifyContent: 'space-between',
  },
  locationName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  buttonsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 15,
    borderRadius: 12,
    alignItems: 'center',
  },
  directionsBtn: {
    backgroundColor: '#007AFF',
  },
  infoBtn: {
    backgroundColor: '#34C759',
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  locationDetailsSection: {
    alignItems: 'center',
  },
  locationDetailsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  // Expanded View
  expandedView: {
    flex: 1,
  },
  expandedScrollView: {
    flex: 1,
  },
  expandedTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
  },
  // Images Section
  imagesSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  imagesContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 8,
  },
  imageWrapper: {
    flex: 1,
    alignItems: 'center',
  },
  evacuationImage: {
    width: '100%',
    height: 100,
    borderRadius: 12,
    marginBottom: 8,
  },
  placeholderImage: {
    width: '100%',
    height: 100,
    borderRadius: 12,
    backgroundColor: '#e9ecef',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#dee2e6',
    borderStyle: 'dashed',
  },
  placeholderText: {
    color: '#6c757d',
    fontSize: 12,
    fontWeight: '500',
  },
  imageLabel: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  // Detail Section
  detailSection: {
    marginBottom: 24,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  detailLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
    flex: 1,
  },
  detailText: {
    fontSize: 16,
    color: '#333',
    flex: 2,
    textAlign: 'right',
  },
  availabilityText: {
    fontSize: 16,
    color: '#34C759',
    fontWeight: 'bold',
    textAlign: 'right',
  },
  // Location Detail Screen Styles
  fullDetailContent: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  fullDetailTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 30,
  },
  fullDetailSection: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  fullDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  fullDetailLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
    flex: 1,
  },
  fullDetailText: {
    fontSize: 16,
    color: '#333',
    flex: 2,
    textAlign: 'right',
  },
  fullAvailabilityText: {
    fontSize: 16,
    color: '#34C759',
    fontWeight: 'bold',
    textAlign: 'right',
  },
  fullDetailButton: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  fullDetailButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  directionsButton: {
    backgroundColor: '#007AFF',
  },
  // User Profile Screen Styles
  profileContent: {
    flex: 1,
    padding: 20,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 30,
    marginTop: 10,
  },
  profileIconContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(0,122,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  profileIcon: {
    fontSize: 50,
  },
  profileName: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  profileEmail: {
    fontSize: 16,
    color: '#666',
    marginBottom: 20,
  },
  profileDetails: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  profileButton: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  profileButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  evacuationSitesButton: {
    backgroundColor: '#FF9500', // Orange color for Evacuation Sites
  },
  logoutButton: {
    backgroundColor: '#FF3B30',
  },
  // Evacuation Sites Screen Styles
  evacuationSitesScrollView: {
    flex: 1,
  },
  evacuationSitesContent: {
    padding: 20,
    paddingBottom: 40,
  },
  evacuationSitesMainTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 30,
    letterSpacing: 1,
  },
  siteManagerHeaderWithButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  siteManagerHeader: {
    alignItems: 'center',
  },
  siteManagerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  plusButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#007AFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  plusButtonText: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    lineHeight: 24,
  },
  sitesListContainer: {
    marginBottom: 20,
  },
  sectionTitleBold: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  sitesList: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  siteItem: {
    fontSize: 16,
    paddingVertical: 8,
    color: '#333',
  },
  divider: {
    height: 1,
    backgroundColor: '#ddd',
    marginVertical: 20,
  },
  evacManagementSection: {
    marginBottom: 20,
  },
  siteManagementList: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  siteManagementItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  siteInfo: {
    flex: 1,
  },
  siteName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  requestNotes: {
    fontSize: 14,
    color: '#666',
    fontStyle: 'italic',
  },
  deleteButton: {
    backgroundColor: '#FF3B30',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
  },
  deleteButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  evacuationButton: {
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  evacuationButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  returnButton: {
    backgroundColor: '#007AFF',
  },
  // Add Evacuation Site Screen Styles
  addSiteMapImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addSiteMapOverlay: {
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 30,
    paddingVertical: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  addSiteMapLabel: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  addSiteInstruction: {
    color: 'white',
    fontSize: 16,
    textAlign: 'center',
  },
  bottomActionContainer: {
    flexDirection: 'row',
    padding: 20,
    paddingBottom: 40,
    gap: 16,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 8,
  },
  cancelButton: {
    backgroundColor: '#FF3B30',
  },
  okButton: {
    backgroundColor: '#34C759',
  },
  // Evac Site Details Screen Styles
  evacSiteDetailsScrollView: {
    flex: 1,
  },
  evacSiteDetailsContent: {
    padding: 20,
    paddingBottom: 40,
  },
  evacSiteMainTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 40,
    letterSpacing: 1,
  },
  // Title Spacing
  titleSpacing: {
    height: 20, // Space between "EVAC SITE" and "DETAILS"
  },
  detailsSection: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  detailsTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  detailField: {
    marginBottom: 20,
  },
  detailLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
    marginBottom: 8,
  },
  detailInput: {
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#dee2e6',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
    minHeight: 44,
    textAlignVertical: 'top',
  },
  // Slots Available Styles
  slotsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  slotButton: {
    width: 44,
    height: 44,
    borderRadius: 8,
    backgroundColor: '#007AFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  slotButtonText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    lineHeight: 20,
  },
  slotsInput: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#dee2e6',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#333',
    minHeight: 44,
    marginHorizontal: 8,
    textAlign: 'center',
  },
  statusDropdown: {
    backgroundColor: '#f8f9fa',
    borderWidth: 1,
    borderColor: '#dee2e6',
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    minHeight: 44,
  },
  statusDropdownText: {
    fontSize: 16,
    color: '#333',
  },
  dropdownArrow: {
    fontSize: 12,
    color: '#666',
  },
  // Modal Styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    width: '80%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  statusOption: {
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  selectedStatusOption: {
    backgroundColor: '#e3f2fd',
  },
  statusOptionText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
  modalCloseButton: {
    marginTop: 10,
    padding: 15,
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
    alignItems: 'center',
  },
  modalCloseButtonText: {
    fontSize: 16,
    color: '#666',
    fontWeight: 'bold',
  },
  // Delete Confirmation Modal Styles
  deleteModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  deleteModalContent: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 24,
    width: '100%',
    maxWidth: 320,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 10,
  },
  deleteModalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 12,
  },
  deleteModalMessage: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  deleteModalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
  },
  deleteModalButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cancelDeleteButton: {
    backgroundColor: '#6c757d',
  },
  confirmDeleteButton: {
    backgroundColor: '#FF3B30',
  },
  cancelDeleteButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  confirmDeleteButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});